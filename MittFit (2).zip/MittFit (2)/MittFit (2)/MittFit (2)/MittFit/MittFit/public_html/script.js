
function redirectToLogin(role) {
  switch(role) {
    case 'user':
      window.location.href = 'user-login-section.html'; 
      break;
    case 'admin':
      window.location.href = 'admin-login.html'; 
      break;
    case 'trainer':
      window.location.href = 'trainer-login.html'; 
      break;
    default:
      // Handle invalid role
      break;
  }
}


